import json
import boto3
import tempfile
import os
import subprocess
import uuid
from datetime import datetime

s3_client = boto3.client('s3')
lambda_client = boto3.client('lambda')
dynamodb = boto3.resource('dynamodb')
analyses_table = dynamodb.Table('golf-coach-analyses')

def lambda_handler(event, context):
    try:
        # Handle S3 event
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        video_key = event['Records'][0]['s3']['object']['key']
        
        print(f"DEBUG: Processing video: {bucket_name}/{video_key}")
        
        # Extract analysis metadata
        user_id = extract_user_id_from_key(video_key)
        analysis_id = extract_analysis_id_from_key(video_key) or str(uuid.uuid4())
        
        update_progress(analysis_id, user_id, "PROCESSING", "DEBUG: Starting diagnostics...")
        
        # Check FFmpeg paths
        ffmpeg_paths = ['/opt/opt/bin/ffmpeg', '/opt/bin/ffmpeg', '/opt/ffmpeg']
        working_ffmpeg = None
        
        for path in ffmpeg_paths:
            if os.path.exists(path):
                print(f"SUCCESS: Found FFmpeg at: {path}")
                # Check if executable
                if os.access(path, os.X_OK):
                    print(f"SUCCESS: {path} is executable")
                    working_ffmpeg = path
                    break
                else:
                    print(f"ERROR: {path} exists but not executable")
        
        if not working_ffmpeg:
            raise Exception(f"No executable FFmpeg found. Checked: {ffmpeg_paths}")
            
        update_progress(analysis_id, user_id, "PROCESSING", f"DEBUG: Found working FFmpeg at {working_ffmpeg}")
        
        # Download video from S3
        temp_video_path = download_video_from_s3(bucket_name, video_key)
        
        update_progress(analysis_id, user_id, "PROCESSING", "DEBUG: Video downloaded, testing FFmpeg...")
        
        # Test FFmpeg with simple command
        test_cmd = [working_ffmpeg, '-version']
        result = subprocess.run(test_cmd, capture_output=True, text=True, timeout=10)
        
        if result.returncode != 0:
            raise Exception(f"FFmpeg test failed: {result.stderr}")
            
        update_progress(analysis_id, user_id, "PROCESSING", "DEBUG: FFmpeg test passed, validating video file...")
        
        # Test video file with simple FFmpeg probe
        probe_cmd = [working_ffmpeg, '-i', temp_video_path, '-f', 'null', '-']
        try:
            probe_result = subprocess.run(probe_cmd, capture_output=True, text=True, timeout=5)
            print(f"Video probe result: {probe_result.returncode}")
            print(f"Video probe stderr: {probe_result.stderr}")
            if probe_result.returncode != 0:
                raise Exception(f"Video file validation failed: {probe_result.stderr}")
        except subprocess.TimeoutExpired:
            raise Exception("Video file validation timed out - file may be corrupt")
        
        update_progress(analysis_id, user_id, "PROCESSING", "DEBUG: Video validated, extracting frames...")
        
        # Extract frames every 0.25 seconds
        extracted_frames = extract_frames_simple(temp_video_path, working_ffmpeg)
        
        if not extracted_frames:
            raise Exception("No frames could be extracted from video")
        
        print(f"SUCCESS: Extracted {len(extracted_frames)} frames")
        
        # Upload frames to S3
        uploaded_frames = upload_frames_to_s3(extracted_frames, bucket_name, analysis_id)
        
        # Create analysis results
        analysis_results = {
            'frames': uploaded_frames,
            'frames_count': len(uploaded_frames),
            'extraction_method': 'debug_simple_quarter_second',
            'ffmpeg_path': working_ffmpeg,
            'processed_at': datetime.utcnow().isoformat()
        }
        
        # Update progress to COMPLETED
        update_progress(analysis_id, user_id, "COMPLETED", 
                       f"DEBUG SUCCESS! {len(uploaded_frames)} frames extracted with {working_ffmpeg}", 
                       analysis_results)
        
        # Trigger AI analysis
        ai_trigger_result = trigger_ai_analysis(analysis_id, user_id)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'analysis_id': analysis_id,
                'status': 'completed',
                'message': f'DEBUG: Frame extraction successful! {len(uploaded_frames)} frames extracted.',
                'ffmpeg_path': working_ffmpeg,
                'frames_count': len(uploaded_frames),
                'ai_trigger': ai_trigger_result
            })
        }
        
    except Exception as e:
        error_msg = f"DEBUG: Frame extraction failed: {str(e)}"
        print(f"ERROR: {error_msg}")
        
        if 'analysis_id' in locals() and 'user_id' in locals():
            update_progress(analysis_id, user_id, "FAILED", error_msg)
        
        return {
            'statusCode': 500,
            'body': json.dumps({'error': error_msg})
        }
    
    finally:
        # Cleanup
        if 'temp_video_path' in locals() and temp_video_path and os.path.exists(temp_video_path):
            os.remove(temp_video_path)

def extract_user_id_from_key(video_key):
    parts = video_key.split('/')
    if len(parts) >= 2 and parts[0] == 'golf-swings':
        return parts[1]
    return 'unknown-user'

def extract_analysis_id_from_key(video_key):
    parts = video_key.split('/')
    if len(parts) >= 3:
        filename = parts[2]
        for ext in ['.mov', '.mp4', '.avi', '.m4v']:
            filename = filename.replace(ext, '')
        return filename
    return None

def download_video_from_s3(bucket_name, video_key):
    try:
        temp_fd, temp_path = tempfile.mkstemp(suffix='.mp4')
        os.close(temp_fd)
        
        print(f"Downloading {video_key}...")
        s3_client.download_file(bucket_name, video_key, temp_path)
        
        file_size = os.path.getsize(temp_path)
        print(f"Downloaded: {file_size / (1024*1024):.2f} MB")
        
        return temp_path
        
    except Exception as e:
        print(f"Download error: {e}")
        raise e

def extract_frames_simple(video_path, ffmpeg_path):
    try:
        # Create temp directory for frames
        temp_dir = tempfile.mkdtemp()
        frame_pattern = os.path.join(temp_dir, 'frame_%03d.jpg')
        
        # Lambda-compatible FFmpeg command to extract frames at 4 fps (every 0.25 seconds)
        ffmpeg_cmd = [
            ffmpeg_path,
            '-nostdin',  # CRITICAL: Prevent FFmpeg from waiting for STDIN input
            '-i', video_path,
            '-vf', 'fps=4',  # 4 frames per second = every 0.25s
            '-q:v', '2',  # High quality
            '-y',  # Overwrite output files
            '-f', 'image2',  # Explicitly specify output format
            frame_pattern
        ]
        
        print(f"Running FFmpeg: {' '.join(ffmpeg_cmd)}")
        print(f"Video file size: {os.path.getsize(video_path) / (1024*1024):.2f} MB")
        print(f"Available temp disk space: {os.statvfs('/tmp').f_bavail * os.statvfs('/tmp').f_frsize / (1024*1024*1024):.2f} GB")
        
        try:
            result = subprocess.run(ffmpeg_cmd, 
                                  stdin=subprocess.DEVNULL,  # CRITICAL: Explicitly close STDIN
                                  capture_output=True, 
                                  text=True, 
                                  timeout=60)  # Increased timeout for larger videos
            
            print(f"FFmpeg return code: {result.returncode}")
            print(f"FFmpeg stderr: {result.stderr}")
            print(f"FFmpeg stdout: {result.stdout}")
            
            if result.returncode != 0:
                raise Exception(f"FFmpeg failed with code {result.returncode}: {result.stderr}")
                
        except subprocess.TimeoutExpired:
            raise Exception(f"FFmpeg timed out after 60 seconds. Video may be too large or corrupt.")
        
        # Collect extracted frames
        extracted_frames = []
        frame_files = sorted([f for f in os.listdir(temp_dir) if f.endswith('.jpg')])
        
        print(f"Found {len(frame_files)} frame files")
        
        for i, frame_file in enumerate(frame_files):
            frame_path = os.path.join(temp_dir, frame_file)
            extracted_frames.append({
                'frame_number': i,
                'timestamp': i * 0.25,  # Every 0.25 seconds
                'frame_path': frame_path
            })
        
        print(f"SUCCESS: FFmpeg extracted {len(extracted_frames)} frames")
        return extracted_frames
        
    except Exception as e:
        print(f"Frame extraction error: {e}")
        raise e

def upload_frames_to_s3(extracted_frames, bucket_name, analysis_id):
    uploaded_frames = []
    
    try:
        for frame_data in extracted_frames:
            # Read frame file
            with open(frame_data['frame_path'], 'rb') as f:
                frame_bytes = f.read()
            
            # S3 key for frame
            frame_key = f"analyses/{analysis_id}/frame_{frame_data['frame_number']:03d}.jpg"
            
            # Upload to S3
            s3_client.put_object(
                Bucket=bucket_name,
                Key=frame_key,
                Body=frame_bytes,
                ContentType='image/jpeg'
            )
            
            # Generate presigned URL
            frame_url = s3_client.generate_presigned_url(
                'get_object',
                Params={'Bucket': bucket_name, 'Key': frame_key},
                ExpiresIn=86400
            )
            
            uploaded_frames.append({
                'frame_number': frame_data['frame_number'],
                'timestamp': frame_data['timestamp'],
                'url': frame_url,
                's3_key': frame_key
            })
            
            # Cleanup temp file
            os.remove(frame_data['frame_path'])
        
        return uploaded_frames
        
    except Exception as e:
        print(f"Frame upload error: {e}")
        raise e

def trigger_ai_analysis(analysis_id, user_id):
    try:
        ai_function_name = os.environ.get('AI_ANALYSIS_PROCESSOR_FUNCTION_NAME', 'golf-ai-analysis-processor')
        
        payload = {
            'analysis_id': analysis_id,
            'user_id': user_id,
            'status': 'COMPLETED'
        }
        
        response = lambda_client.invoke(
            FunctionName=ai_function_name,
            InvocationType='Event',
            Payload=json.dumps(payload)
        )
        
        return {
            'success': True,
            'status_code': response.get('StatusCode'),
            'ai_function': ai_function_name
        }
        
    except Exception as e:
        return {
            'success': False,
            'error': str(e)
        }

def update_progress(analysis_id, user_id, status, message, analysis_data=None):
    try:
        item = {
            'analysis_id': analysis_id,
            'user_id': user_id,
            'status': status,
            'progress_message': message,
            'updated_at': datetime.utcnow().isoformat()
        }
        
        if status == "STARTED":
            item['created_at'] = datetime.utcnow().isoformat()
        
        if analysis_data:
            item['analysis_results'] = analysis_data
        
        analyses_table.put_item(Item=item)
        print(f"Progress: {status} - {message}")
        
    except Exception as e:
        print(f"DynamoDB update error: {e}")