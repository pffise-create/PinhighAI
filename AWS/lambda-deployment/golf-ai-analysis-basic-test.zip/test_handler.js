exports.handler = async (event) => {
    console.log('BASIC TEST');
    return { statusCode: 200 };
};